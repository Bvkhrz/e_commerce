console.log(card);
