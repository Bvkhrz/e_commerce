let products;
let products_list = document.getElementById('products_list');
let loader = document.getElementById('loader');

async function getProducts() {
	let res = await fetch(`https://fakestoreapi.com/products`, {
		method: 'GET',
	}).finally(() => {
		loader.classList.add('hidden');
	});

	res = await res.json();

	render(res);
	products = res;
}

getProducts();

function render(products) {
	let fragment = document.createDocumentFragment();
	products_list.innerHTML = null;
	products.forEach((item) => {
		let div1 = document.createElement('div');
		div1.classList.add(
			'w-[30%]',
			'p-4',
			'border',
			'border-[#444444]',
			'rounded-md'
		);

		let div_img = document.createElement('div');
		div_img.classList.add('w-[full]', 'overflow-hidden');

		let product_img = document.createElement('img');
		product_img.src = item.image;
		product_img.alt = item.title;
		product_img.classList.add(
			'rounded-md',
			'w-[323px]',
			'h-[280px]',
			'object-cover'
		);

		div_img.appendChild(product_img);

		let div_title = document.createElement('div');
		div_title.classList.add('flex', 'flex-col', 'items-start', 'gap-4');

		let h1 = document.createElement('h1');
		h1.textContent =
			item.title.length >= 5
				? item.title.slice(0, 20) + ' ...'
				: item.title;

		let p = document.createElement('p');
		p.textContent =
			item.description.length >= 10
				? item.description.slice(0, 50) + ' ...'
				: item.description;

		let categoriy_span = document.createElement('span');
		categoriy_span.textContent = item.category.name;
		categoriy_span.classList.add(
			'bg-[#333333]',
			'rounded-xl',
			'py-1',
			'px-3',
			'text-[gray]'
		);

		div_title.appendChild(h1);
		div_title.appendChild(p);
		div_title.appendChild(categoriy_span);

		let div_bottom = document.createElement('div');
		div_bottom.classList.add(
			'flex',
			'justify-between',
			'items-end',
			'w-[full]'
		);

		let div_price = document.createElement('div');
		div_price.classList.add('flex', 'flex-col', 'my-2');

		let price_span = document.createElement('span');
		price_span.textContent = 'price';
		price_span.classList.add('text-[gray]');

		let dollar_span = document.createElement('span');
		dollar_span.textContent = item.price + '$';

		div_price.appendChild(price_span);
		div_price.appendChild(dollar_span);
		div_bottom.appendChild(div_price);

		let button = document.createElement('button');
		button.textContent = 'Add to Card';
		button.classList.add(
			'px-3',
			'py-2',
			'bg-[#885DF8]',
			'rounded-md',
			'active:bg-[#885DF8]/50'
		);
		button.setAttribute('onclick', `addToCatch(${item.id})`);

		div_bottom.appendChild(button);

		div1.appendChild(div_img);
		div1.appendChild(div_title);
		div1.appendChild(div_bottom);

		fragment.appendChild(div1);
	});
	products_list.appendChild(fragment);
}

let Category_list = document.getElementById('Category_list');

function category() {
	fetch(`https://fakestoreapi.com/products/categories`, {
		method: 'GET',
	})
		.then((res) => {
			return res.json();
		})
		.then((res) => {
			res = ['all', ...res];
			renderCategory(res);
		})
		.catch((err) => {
			console.log(err);
		});
}

category();

async function catogoryId(i) {
	if (i === 'all') {
		getProducts();
		return;
	}

	let catogoryId = await fetch(
		`https://fakestoreapi.com/products/category/${i}`,
		{
			method: 'GET',
		}
	);
	catogoryId = await catogoryId.json();

	render(catogoryId);
}

catogoryId();

function renderCategory(categoris) {
	categoris.forEach((categoria) => {
		let span_category = document.createElement('button');
		span_category.textContent = categoria;
		span_category.setAttribute('onclick', `catogoryId("${categoria}")`);
		span_category.classList.add(
			'p-2',
			'text-start',
			'w-[220px]',
			'bg-[black]',
			'active:bg-[black]/70'
		);
		Category_list.appendChild(span_category);
	});
}

let search_input = document.querySelector('#search_input');
let product_card = [];

fetch('https://fakestoreapi.com/products')
	.then((response) => response.json())
	.then((data) => {
		products = data;
		render(products);
	})
	.catch((error) => console.error('API xatosi:', error));

function search() {
	if (!products || products.length === 0) {
		console.error("Products hali yuklanmagan yoki bo'sh!");
		return;
	}

	const product = products.find((item) => {
		return item.title
			.toLowerCase()
			.includes(search_input.value.trim().toLowerCase());
	});

	if (product) {
		console.log(product);
		render([product]);
	} else {
		console.log('Mahsulot topilmadi!');
		products_list.innerHTML = '<p>No product found!</p>';
	}

	clear();
}

function clear() {
	search_input.value = '';
}

let store_index = document.getElementById('store_index');
let store_box = document.getElementById('store_box');

let card = [];
let i = 0;

async function addToCatch(id) {
	let product = await fetch(`https://fakestoreapi.com/products/${id}`, {
		method: 'GET',
	});

	product = await product.json();
	card.push(product);
	renderStore(card);

	i++;
	store_index.textContent = i;

	console.log(product);
}

const showStore = () => {
	console.log('Show Store');
	store_box?.classList.toggle('translate-x-[10px]');
};

function renderStore(card) {
	let fragment = document.createDocumentFragment();
	store_box.innerHTML = null;
	card.forEach((item) => {
		let div1 = document.createElement('div');
		div1.classList.add(
			'text-white',
			'flex',
			'justify-between',
			'items-center'
		);

		let left_card = document.createElement('div');
		left_card.classList.add('flex', 'items-center', 'gap-4');

		let product_img = document.createElement('img');
		product_img.src = item.image;
		product_img.alt = item.title;
		product_img.classList.add('w-23', 'h-20', 'rounded-lg');

		left_card.appendChild(product_img);

		let text_box = document.createElement('div');
		let title = document.createElement('p');
		title.textContent = item.title;

		let price = document.createElement('p');
		price.textContent = '$' + item.price;
		text_box.appendChild(title);
		text_box.appendChild(price);

		left_card.appendChild(product_img);
		left_card.appendChild(text_box);

		let button = document.createElement('button');
		button.textContent = 'Add to Card';
		button.classList.add(
			'px-3',
			'py-2',
			'bg-[#885DF8]',
			'rounded-md',
			'active:bg-[#885DF8]/50'
		);

		let right_card = document.createElement('div');
		let remove_btn = document.createElement('button');
		remove_btn.textContent = 'Remove';
		remove_btn.classList.add('bg-bg_btn', 'py-2', 'px-4', 'rounded-lg');
		let minus = document.createElement('button');
		minus.classList.add('bg-bg_btn', 'py-2', 'py-2', 'px-4', 'rounded-lg');
		minus.textContent = '-';
		let count = document.createElement('span');
		count.textContent = 1;

		let plus = document.createElement('button');
		plus.textContent = '+';
		plus.classList.add('bg-bg_btn', 'py-2', 'px-4', 'rounded-lg');
		right_card.appendChild(remove_btn);
		right_card.appendChild(minus);
		right_card.appendChild(count);
		right_card.appendChild(plus);
		button.setAttribute('onclick', `addToCatch(${item.id})`);

		div1.appendChild(left_card);
		div1.appendChild(right_card);

		fragment.appendChild(div1);
	});
	store_box.appendChild(fragment);
}

// let cards = document.createElement('div');
// cards.classList.add(
//    'text-white',
//    'flex',
//    'justify-between',
//    'items-center'
// );
// let left_card = document.createElement('div');
// left_card.classList.add('flex', 'items-center', 'gap-4');

// let left_card_img = document.createElement('img');
// left_card_img.src = item?.image;
// left_card_img.alt = item?.title;
// left_card_img.classList.add('w-20', 'h-20', 'rounded-lg');

// let text_box = document.createElement('div');
// let title = document.createElement('p');
// title.textContent = item.title;

// let price = document.createElement('p');
// price.textContent = '$' + item.price;
// text_box.appendChild(title);
// text_box.appendChild(price);

// left_card.appendChild(left_card_img);
// left_card.appendChild(text_box);

// fragment.appendChild(cards);
